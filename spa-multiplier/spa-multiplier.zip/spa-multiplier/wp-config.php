<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'spa-db' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'c| *aBXtmqR4#`hp&3Z}<UJu^1(*g4$L1Oz.Gk}@$#I9sFQ=M^b)/MR{)MP$Wk5g' );
define( 'SECURE_AUTH_KEY',  '5rn<JD1p{`zUJc)Bw- ?2H&44ctAmE?`_7Y6|xxZVm%B#PB],n7c[hvqC{NMz8f!' );
define( 'LOGGED_IN_KEY',    '6(b<;W6!-hl}U?Q!@D@3#=cbFCQi#xQKKJm%y:C6T,Y0QZ12@=[UNJZ;bnA4`$-O' );
define( 'NONCE_KEY',        '(UXxj8hfD.N*<AL2`j>{P@(5E_R+^Q*BJYcNP}ycvYZoAB/FKz7mDMO{k,F)^7rX' );
define( 'AUTH_SALT',        'A1i=n/<u2(}1!_~=AQ`1P6V{o^|?n9%YjcM|E8OPu,FgB.i1bVI!iScTip=0*%d{' );
define( 'SECURE_AUTH_SALT', 'sZAreS3#dGt+f<6}9jx}.|5/KC:9i)1=mI0[:~ Qx^>EQZY0H?*wyhy9ot9~4bl;' );
define( 'LOGGED_IN_SALT',   'LvV=5Wy$0DM/;vH<P+K,5|~Z(Wz4ypNkS(voq?Zr6BIbmPw>kzi>O5b&}{_=/RuB' );
define( 'NONCE_SALT',       'Yc3pe/gYy$s+=v{e,*VHYI-{tRR?A8sEPm:bNYFu:pP}gk7wn_90_4R4+zh6LsQ1' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
